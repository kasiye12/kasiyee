﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRM2.Models
{
    public class jobs
    {
        public int ID { get; set; }
        public string jobs_name { get; set; }
        public string jobs_subname { get; set; }
        public string jobs_type { get; set; }
       
    }
}