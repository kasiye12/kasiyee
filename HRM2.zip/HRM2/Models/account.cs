﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.IO;
namespace HRM2.Models
{
    public class account
    {
        [Key]
        public int UserID { get; set; }
        [Required(ErrorMessage = "First name is requured.")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last name is requured.")]
        public string LastNmae { get; set; }
        [Required(ErrorMessage = "Email is requured.")]
        public string Email { get; set; }
        [Required(ErrorMessage = "username is requured.")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "password is requured.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Compare("Password", ErrorMessage = "pleace confirm your password.")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }
        //public role role { get; set; }
        //public int? RoleID { get; set; }
    }
}