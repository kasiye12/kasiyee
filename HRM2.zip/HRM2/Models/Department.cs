﻿namespace HRM2.Models
{
    public class Department
    {
        // GET: Department
        public int ID { get; set; }
        public string departmentname { get; set; }
        public string country { get; set; }
    }
}